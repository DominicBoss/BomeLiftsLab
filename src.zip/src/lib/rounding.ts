export function roundTo2_5(x: number) {
  return Math.round(x / 2.5) * 2.5
}