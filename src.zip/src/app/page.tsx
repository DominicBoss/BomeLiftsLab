export default function Home() {
  return <div className="p-6">Loading...</div>
}